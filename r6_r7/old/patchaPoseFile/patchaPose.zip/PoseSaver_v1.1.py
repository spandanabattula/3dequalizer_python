# 3DE4.script.name: Pose Saver/Loader
#
# 3DE4.script.version:	v1.1
# 		
# 3DE4.script.gui:Main Window::3DE4
#
# 3DE4.script.comment: Imports 3D rot/pos channels from a .pose file.
#
# Author : Patcha Saheb (patchasaheb@gmail.com)


from vl_sdv import *
import math

window_title = "Pose Saver/Loader v1.1"

def ImportCameraPose():
	pg	= tde4.getCurrentPGroup()
	cam     = tde4.getCurrentCamera()
	frame   = tde4.getCurrentFrame(cam)
	if pg!=None and cam !=None:
		if tde4.getPGroupType(pg)=="CAMERA" or tde4.getCameraType(cam) =="REF_FRAME":
			path	= tde4.getWidgetValue(req,"file_browser")
			if path!=None:
				f	= open(path,"r")
				if not f.closed:
					string	= f.readline()
					a	= string.split()
					if len(a) == 6:
						# read values from .pose file..
						pos_x	= float(a[0])
						pos_y	= float(a[1])
						pos_z	= float(a[2])
						rot_x	= float(a[3])
						rot_y	= float(a[4])
						rot_z	= float(a[5])
						# matrix 3D...
						rot_x	= (rot_x*3.141592654)/180.0
						rot_y	= (rot_y*3.141592654)/180.0
						rot_z	= (rot_z*3.141592654)/180.0
						r3d	= mat3d(rot3d(rot_x,rot_y,rot_z,VL_APPLY_ZXY))
						r3d0	= [[r3d[0][0],r3d[0][1],r3d[0][2]],[r3d[1][0],r3d[1][1],r3d[1][2]],[r3d[2][0],r3d[2][1],r3d[2][2]]]
						# setting point group position and rotation...
						tde4.setPGroupPosition3D(pg,cam,frame,[pos_x,pos_y,pos_z])
						tde4.setPGroupRotation3D(pg,cam,frame,r3d0)
						tde4.setPGroupPostfilterMode(pg,"POSTFILTER_OFF")
						tde4.filterPGroup(pg,cam)
					else: 
						tde4.postQuestionRequester(window_title,"there must be exactly 6 values in a row","ok")
		else:
			tde4.postQuestionRequester(window_title,"CameraPGroup/REF Camera must be selected.", "ok")						
	else:
		tde4.postQuestionRequester(window_title, "there must be a Camera and PointGroup.", "ok")			

def convertToAngles(r3d):
		rot	= rot3d(mat3d(r3d)).angles(VL_APPLY_ZXY)
		rx	= (rot[0]*180.0)/3.141592654
		ry	= (rot[1]*180.0)/3.141592654
		rz	= (rot[2]*180.0)/3.141592654
		return(rx,ry,rz)
		
def ExportCameraPose():
	pg 	= tde4.getCurrentPGroup()
	cam	= tde4.getCurrentCamera()
	frame= tde4.getCurrentFrame(cam)
	typ	= tde4.getPGroupType(pg)
	if pg !=None and cam !=None:
		if typ == "CAMERA" or typ == "REF_FRAME":
			sellist = tde4.getCameraList(1)
			if len(sellist) < 2:
				#getting PGroup position and rotation...
				p3d = tde4.getPGroupPosition3D(pg,cam,frame)
				r3d = tde4.getPGroupRotation3D(pg,cam,frame)
				path	= tde4.getWidgetValue(req,"file_browser")
				#writing values to file...
				f = open(path,"w")
				f.write("%.15f %.15f %.15f %.15f %.15f %.15f "%(p3d[0],p3d[1],p3d[2],convertToAngles(r3d)[0],convertToAngles(r3d)[1],convertToAngles(r3d)[2]))
				f.close()
			else:
				tde4.postQuestionRequester(window_title,"CameraPGroup/REF Camera must be selected.", "ok")
	else:
		tde4.postQuestionRequester(window_title, "there must be a Camera and PointGroup.", "ok")	
		
def ImportObjPose():
	pg	= tde4.getCurrentPGroup()
	cam     = tde4.getCurrentCamera()
	frame   = tde4.getCurrentFrame(cam)
	if pg!=None and cam !=None:
		if tde4.getPGroupType(pg)=="OBJECT":
			path	= tde4.getWidgetValue(req,"file_browser")
			if path!=None:
				f	= open(path,"r")
				if not f.closed:
					string	= f.readline()
					a	= string.split()
					if len(a) == 6:
						# read values from .pose file..
						pos_x	= float(a[0])
						pos_y	= float(a[1])
						pos_z	= float(a[2])
						rot_x	= float(a[3])
						rot_y	= float(a[4])
						rot_z	= float(a[5])
						# matrix 3D...
						rot_x	= (rot_x*3.141592654)/180.0
						rot_y	= (rot_y*3.141592654)/180.0
						rot_z	= (rot_z*3.141592654)/180.0
						r3d	= mat3d(rot3d(rot_x,rot_y,rot_z,VL_APPLY_ZXY))
						r3d0	= [[r3d[0][0],r3d[0][1],r3d[0][2]],[r3d[1][0],r3d[1][1],r3d[1][2]],[r3d[2][0],r3d[2][1],r3d[2][2]]]
						# setting point group position and rotation...
						newvalues = tde4.convertObjectPGroupTransformationWorldTo3DE(cam, frame, r3d0, [pos_x,pos_y,pos_z], 1.0, 0)
						tde4.setPGroupPosition3D(pg,cam,frame,newvalues[1])
						tde4.setPGroupRotation3D(pg,cam,frame,newvalues[0])
						tde4.setPGroupPostfilterMode(pg,"POSTFILTER_OFF")
						tde4.filterPGroup(pg,cam)
						tde4.setPGroupScale3D(pg,1.0)
						tde4.updateGUI()
		else:
			tde4.postQuestionRequester(window_title,"ObjectPGroup must be selected.", "ok")
	else:
		tde4.postQuestionRequester(window_title, "there must be a Camera and PointGroup.", "ok")	
		
def ExportObjPose():
	pg 	= tde4.getCurrentPGroup()
	cam	= tde4.getCurrentCamera()
	frame= tde4.getCurrentFrame(cam)
	typ	= tde4.getPGroupType(pg)
	if pg !=None and cam !=None:
		if typ == "OBJECT":
			#getting PGroup position and rotation...
			p3d = tde4.getPGroupPosition3D(pg,cam,frame)
			r3d = tde4.getPGroupRotation3D(pg,cam,frame)
			path	= tde4.getWidgetValue(req,"file_browser")
			#new_values = tde4.convertObjectPGroupTransformation3DEToWorld(cam,frame,r3d,p3d,1.0,0)
			#r3d = new_values[0]
			#p3d = new_values[1]
			#writing values to file...
			f = open(path,"w")
			f.write("%.15f %.15f %.15f %.15f %.15f %.15f "%(p3d[0],p3d[1],p3d[2],convertToAngles(r3d)[0],convertToAngles(r3d)[1],convertToAngles(r3d)[2]))
			f.close()
		else:
			tde4.postQuestionRequester(window_title,"ObjectPGroup must be selected.", "ok")
	else:
		tde4.postQuestionRequester(window_title, "there must be a Camera and PointGroup.", "ok")	

def doIt():
	if ret == 1:
		menu1_value = tde4.getWidgetValue(req,"mode_menu1")
		menu2_value = tde4.getWidgetValue(req,"mode_menu2")
		if menu1_value == 1 and menu2_value == 1:
			ImportCameraPose()
		if menu1_value == 1 and menu2_value == 2:
			ExportCameraPose()
		if menu1_value == 2 and menu2_value == 1:
			ImportObjPose()
		if menu1_value == 2 and menu2_value == 2:
			ExportObjPose()

try:
	req	= _scale_requester
except (ValueError,NameError,TypeError):
	req	= tde4.createCustomRequester()
	_scale_requester	= req
	
	tde4.addFileWidget(req,"file_browser","Browse...","*.pose")
	tde4.addOptionMenuWidget(req,"mode_menu1","Select Type PGroup","Camera/REF Camera","Object")
	tde4.setWidgetAttachModes(req,"mode_menu1","ATTACH_POSITION","ATTACH_POSITION","ATTACH_WINDOW","ATTACH_AS_IS")
	tde4.setWidgetOffsets(req,"mode_menu1",30,95,45,0)	
	tde4.addOptionMenuWidget(req,"mode_menu2","Import/Export","Import","Export")
	tde4.setWidgetAttachModes(req,"mode_menu2","ATTACH_POSITION","ATTACH_POSITION","ATTACH_WINDOW","ATTACH_AS_IS")
	tde4.setWidgetOffsets(req,"mode_menu2",30,95,85,0)	
	
ret = tde4.postCustomRequester(req,window_title,500,180,"Ok","Cancel")	

doIt()
